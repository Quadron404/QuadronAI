export async function onRequestPost(context) {

const { request, env } = context

try {

const { message } = await request.json()

if (!message) {
return new Response(JSON.stringify({ reply: "No message sent" }), {
headers: { "Content-Type": "application/json" }
})
}

const aiRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
method: "POST",
headers: {
"Content-Type": "application/json",
"Authorization": "Bearer " + env.GROQ_API_KEY
},
body: JSON.stringify({
model: "llama-3.1-8b-instant",
messages: [
{ role: "system", content: "You are Quadron AI, sarcastic and smart." },
{ role: "user", content: message }
]
})
})

const data = await aiRes.json()

return new Response(JSON.stringify({
reply: data.choices?.[0]?.message?.content || "No AI reply"
}), {
headers: { "Content-Type": "application/json" }
})

} catch (err) {

return new Response(JSON.stringify({
reply: "Backend error"
}), {
headers: { "Content-Type": "application/json" }
})

}

}